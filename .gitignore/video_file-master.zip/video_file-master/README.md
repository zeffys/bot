# The code of the video

Don't share the code.
